# Carteira de 50 estratégias — BTC 30min com filtro HMA MTF (dados até dez/2023)

Filtro de tendência: estratégia "HMA Crossover Multi-Timeframe" (`scripts/study_hmamtf.py`, HMA 16/65 no 4H, RSI 52, linreg diária, versão long+short). Um trade de 30min só entra se o HMA estiver do mesmo lado na entrada; HMA fora do mercado = nenhum trade. Estado da última barra 4H fechada (sem look-ahead).

Seleção: só configurações com ≥ 100 trades, a de maior CAGR por estratégia, e as 50 primeiras por CAGR (macdsma fora: não passa pelo filtro). Correlação média 0,28. Carteira de peso igual 2020–2023: CAGR 26,8% a.a., Sharpe 1,88, DD −7,8% (B&H: 55,8% a.a., DD −77%). Ver `carteira50_vs_bh.png`.

- `selecao50.csv`: as 50 (`id` = estudo|est|cfg) com as estatísticas e `trades_sem_filtro`.
- `trades/trades_50.csv`: todos os trades filtrados (t_in/t_out, d, entry/exit, bruto, fund, ret_sf, ret).
- `trades/retornos_diarios_50.csv`: retorno diário de cada uma.
- `scripts/rodar_carteira50_btc30m_hma.py`: reproduz tudo (lotes + filtro) e monta a carteira.

```
pip install -r requirements.txt
cd scripts
EDGE_END=2023-12-31 python rodar_carteira50_btc30m_hma.py              # período da seleção
EDGE_END=2025-06-30 python rodar_carteira50_btc30m_hma.py 2024-01-01   # fora da amostra
```
Dados: `data/binance/klines_1m/BTCUSDT.parquet` (Binance perp 1m, 2020 a set/2026).
Limitação: o filtro descarta trades depois de gerados; em estratégias cuja entrada depende da posição anterior é uma aproximação.

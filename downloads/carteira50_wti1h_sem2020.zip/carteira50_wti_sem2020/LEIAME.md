# Carteira de 50 estratégias — WTI 1h, seleção excluindo 2020 (dados até dez/2023)

- `selecao50.csv`: as 50 configurações (`id` = estudo|est|cfg), com as estatísticas até dez/2023 (colunas _sem2020 calculadas sem o ano de 2020) e a correlação média de cada uma com o grupo.
- `trades/trades_50.csv`: todos os trades das 50 até dez/2023 (t_in/t_out, d = +1 compra/−1 venda, entry/exit, bruto, fund, ret_sf, ret líquido), ligados pela coluna `id`.
- `trades/retornos_diarios_50.csv`: retorno diário de cada uma (uma coluna por `id`).
- `scripts/rodar_carteira50_wti1h.py`: roda os lotes pelo mesmo código da planilha e monta a carteira de peso igual.

```
pip install -r requirements.txt
cd scripts
EDGE_END=2023-12-31 python rodar_carteira50_wti1h.py              # período da seleção
EDGE_END=2025-06-30 python rodar_carteira50_wti1h.py 2024-01-01   # fora da amostra: jan/2024 a jun/2025
```
Roda 21 lotes inteiros (uns 40 min com 4 núcleos). Dados: `data/duka1m_wti/all.parquet` (Dukascopy 1m, jan/2017 a set/2026).
A seleção ignorou 2020 inteiro (trades, CAGR e correlação). Os trades e retornos incluem 2020 para referência; filtre o ano se quiser.

# Carteira de 50 estratégias — XAG (prata) 30min com filtro HMA MTF (dados até dez/2023)

Mesmo procedimento do BTC: todas as estratégias em 30min; um trade só entra se a "HMA Crossover Multi-Timeframe" (`scripts/study_hmamtf.py`, 4H, long+short, parâmetros publicados) estiver do mesmo lado na entrada (estado da última barra 4H fechada, sem look-ahead). Depois: só configurações com ≥ 100 trades, a de maior CAGR por estratégia, e as 50 de maior CAGR.

Resultado 2020–2023: correlação média 0,31; carteira de peso igual CAGR 10,2% a.a., Sharpe 1,16, DD −6,4%; buy & hold da prata 7,4% a.a., Sharpe 0,34, DD −40%. Ver `carteira50_vs_bh.png`.

- `selecao50.csv`, `trades/trades_50.csv`, `trades/retornos_diarios_50.csv`: lista, trades filtrados e retornos diários (coluna `id` = estudo|est|cfg).
- `scripts/rodar_carteira50_xag30m_hma.py`: reproduz tudo (lotes + filtro) e monta a carteira.

```
pip install -r requirements.txt
cd scripts
EDGE_END=2023-12-31 python rodar_carteira50_xag30m_hma.py              # período da seleção
EDGE_END=2025-06-30 python rodar_carteira50_xag30m_hma.py 2024-01-01   # fora da amostra
```
Dados: `data/silver/xag_1m.parquet` (Dukascopy XAG-USD 1m, jan/2020 a nov/2026).
Limitação: o filtro descarta trades depois de gerados; em estratégias cuja entrada depende da posição anterior é uma aproximação.

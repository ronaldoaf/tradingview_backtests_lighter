# Carteira de 50 estratégias — US100 1h (dados até dez/2023)

Seleção: as 50 de maior CAGR, percorrendo a lista em ordem de CAGR e aceitando cada uma só se a correlação média do grupo (retornos diários) continuar ≤ 0,33. Único filtro extra: fora os controles com lookahead proposital.

- `selecao50.csv`: as 50 (`id` = estudo|est|cfg) com as estatísticas até dez/2023 e a correlação média de cada uma com o grupo.
- `trades/trades_50.csv`: todos os trades das 50 (t_in/t_out, d = +1 compra/−1 venda, entry/exit, bruto, fund, ret_sf, ret líquido).
- `trades/retornos_diarios_50.csv`: retorno diário de cada uma.
- `scripts/rodar_carteira50_us1001h.py`: roda os lotes pelo mesmo código da planilha e monta a carteira de peso igual.

```
pip install -r requirements.txt
cd scripts
EDGE_END=2023-12-31 python rodar_carteira50_us1001h.py              # período da seleção
EDGE_END=2025-06-30 python rodar_carteira50_us1001h.py 2024-01-01   # fora da amostra
```
Dados: `data/duka1m_us100/all.parquet` (Dukascopy 1m, jan/2017 a ago/2026).
